package com.example.controller.stu;

import com.example.dao.MarkDao;
import com.example.dao.TaskDao;
import com.example.entity.MarkEntity;
import com.example.entity.TaskEntity;
import com.example.entity.UserEntity;
import com.example.dao.UserDao;
import com.mysql.cj.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @author HXJ
 * # 修改密码
 * # 查询课程
 * # 查询我的成绩
 */
@Controller
@RequestMapping("/stu")
public class MyStuController {

    @Autowired
    UserDao userDao;
    @Autowired
    TaskDao taskDao;
    @Autowired
    MarkDao markDao;

    @RequestMapping("/go2Pwd")
    public String go2Pwd(Model model) {
        model.addAttribute("action", "update");
        return "/stu/show";  // 返回显示密码更新页面
    }

    @PostMapping("/update")
    public String pwd(String uid, String oldPwd, String newPwd, String twoNewPwd, Model model, HttpServletRequest request) {
        HttpSession session = request.getSession();
        UserEntity userEntity = (UserEntity) session.getAttribute("user");

        if (userEntity == null || !userEntity.getPwd().equals(oldPwd)) {
            model.addAttribute("action", "update");
            model.addAttribute("error", "旧密码错误");
            return "/stu/show";  // 返回显示页面
        }

        if (!newPwd.equals(twoNewPwd)) {
            model.addAttribute("action", "update");
            model.addAttribute("error", "新密码和确认密码不一致");
            return "/stu/show";  // 返回显示页面
        }

        userEntity.setPwd(newPwd);
        userDao.update(userEntity);  // 更新密码
        model.addAttribute("message", "密码更新成功");
        return "/main";
        // 返回显示页面
    }
    @GetMapping("/go2Course")
    public String go2Course(Model model, HttpSession session) {
        model.addAttribute("action", "course");
        UserEntity user = (UserEntity) session.getAttribute("user");
        List<TaskEntity> taskDaoByClzno = taskDao.findByClzno(user.getClzno());
        model.addAttribute("taskEntityList", taskDaoByClzno);
        return "/stu/show";
    }
    @GetMapping("/go2score")
    public String go2score(Model model, HttpSession session) {
        model.addAttribute("action", "score");
        UserEntity user = (UserEntity) session.getAttribute("user");
        List<MarkEntity> markEntityList = markDao.findBySno(user.getPhone());
        markEntityList.forEach(System.out::println);
        System.out.println("markEntityList: " + markEntityList);
        model.addAttribute("markEntityList", markEntityList);
         return "/stu/show";
    }
}