package com.example.controller.tea;

import com.example.dao.MarkDao;
import com.example.dao.TaskDao;
import com.example.dao.UserDao;
import com.example.entity.MarkEntity;
import com.example.entity.TaskEntity;
import com.example.entity.UserEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author HJX
 * # 修改我的密码
 * # 登分
 */
@Controller
@RequestMapping("/tea")
public class MyTeaController {
    @Autowired
    UserDao userDao;
    @Autowired
    MarkDao markDao;
    @Autowired
    TaskDao taskDao;
    public MyTeaController() {
        System.out.println("MyTeaController 构造");
    }

    //修改密码
    @RequestMapping("/go2Pwd")
    public String go2Pwd(Model model) {
        model.addAttribute("action", "update");
        return "/tea/show";  // 返回显示密码更新页面
    }
    //登分
    @PostMapping("/update")
    public String pwd(String uid,String oldPwd, String newPwd, String twoNewPwd ,Model model) {
        System.out.println(uid);
        if (newPwd.equals(twoNewPwd) && !newPwd.isEmpty()) {
            UserEntity userEntity = new UserEntity();
            userEntity.setPwd(newPwd);
            userDao.updatePwd(userEntity);
            return "forward:/stu/go2show";
        }
        return "forward:/tea/update";
    }
    @GetMapping("/go2score")
    public String go2score(Model model,HttpSession session) {
        model.addAttribute("action", "score");
        UserEntity user = (UserEntity) session.getAttribute("user");
        List<TaskEntity> taskEntityList = taskDao.findByTid(user.getUid());
        model.addAttribute("taskEntityList", taskEntityList);
        return "/tea/show";
    }

    @PostMapping("/tea/score")
    public String score(@RequestParam("sno") String sno,
                              @RequestParam("cno") String cno,
                              @RequestParam("score") BigDecimal score,
                              @RequestParam("tid") int tid,
                              Model model) {
        MarkEntity mark = new MarkEntity();
        mark.setSno(sno);
        mark.setCno(cno);
        mark.setScore(score);
        mark.setTid(tid);
        mark.setTpost(new Date());

        int result = markDao.add(mark);
        model.addAttribute("message", result > 0 ? "分数提交成功" : "分数提交失败");

        return "forward:/tea/go2score";
    }
}
